from setuptools import setup

setup(
    name="homework_exercise",
    version = "0.1",
    license_files = 'LICENSE.txt'
)
